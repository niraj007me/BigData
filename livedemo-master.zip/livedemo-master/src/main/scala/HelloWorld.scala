/**
  * Created by itversity on 17/06/18.
  */
object HelloWorld {
  def main(args: Array[String]): Unit = {
    println("Hello World")
  }

}
