/**
  * Created by itversity on 04/06/18.
  */
object HW {
  def main(args: Array[String]): Unit = {
    println("Hello " + args(0))

  }

}
